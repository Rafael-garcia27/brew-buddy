# Handoff: Organic-Reskin für die Barista-App (nur Design)

> **Kurz für Claude Code:** Diese Datei ist die komplette Anleitung. Lies sie ganz, dann `design/Barista App.dc.html` als visuelle Referenz. Setze **ausschließlich die Optik** um. Funktionen, Inhalte, Texte, Datenflüsse und Tests bleiben unverändert.

---

## 0. Prompt zum Einfügen in Claude Code

```
Lies design_handoff_organic_reskin/README.md vollständig und setze den Reskin
in diesem Repo um. Es geht NUR um Design: Farben, Schriften, Radien, Abstände,
Höhen, Schatten, Icon-Strichstärken. Ändere keine Funktionen, keine Texte,
keine Props/Signaturen, keine Reihenfolge von Inhalten, keine Navigation.
Arbeite in den Phasen aus Abschnitt 4, führe nach jeder Phase
`npm run pruefen` aus und halte an, wenn etwas rot wird.
```

---

## 1. Überblick

Die App (React 19 + Vite + Tailwind v4, PWA) bekommt die Oberfläche des **Organic**-Systems: cremefarbener Grund, Terracotta-Akzent, Salbei als „im Fenster/gut“, Caprasimo für Überschriften, Figtree für alles andere, stark gerundete Flächen und Pillen-Buttons.

Die Informationsarchitektur, die Engine (`src/engine/*`), die Wissensbasis, der Store und alle deutschen Texte bleiben **exakt** wie sie sind.

## 2. Harte Grenzen (nicht verhandelbar)

**Nicht anfassen:**
- `src/engine/**`, `src/store/**`, `src/kb/**`, `src/domain/**`, `data/**`, `kb/**`, `types/**`
- `src/router.tsx`, `src/labels.ts`, `src/config.ts`, `src/main.tsx`
- Alle `*.test.ts` — sie müssen ohne Änderung grün bleiben
- Texte/Copy in JSX, `aria-label`s, Reihenfolge und Anzahl der Elemente
- Props, Typen, Exporte, Hooks, Handler, Zustandslogik in Komponenten

**Erlaubt:**
- `src/index.css` (Tokens, `@theme`, `@font-face`, Basisstile)
- `className`-Strings und `style`-Objekte in `src/components/*.tsx` und `src/screens/*.tsx`
- `strokeWidth` und Pfade von Inline-SVG-Icons (gleiche Bedeutung, gleiche Größe ±2 px)
- `index.html` (nur `<link rel="preload">` für Schriften, `theme-color`)
- `public/fonts/*` (neu, Schriftdateien)

**Wichtige Stolperfallen im Repo:**
- `src/kb/roast-process.test.ts` liest `index.css` und schneidet ab `html.dark` — der Selektor `html.dark` und alle `--c-roast-*`-Variablen müssen **wörtlich** erhalten bleiben.
- `scripts/kontrast.mjs` (`npm run kontrast`) prüft die Tokens gegen WCAG AA. Alle neuen Werte unten sind darauf ausgelegt; schlägt eine Paarung fehl, den Wert **entlang der angegebenen Rampe dunkler/heller** schieben, nicht die Prüfung ändern.
- `store/index.ts` schaltet Dunkel über `html.dark`. Das bleibt so. (Das Mockup nutzt `[data-theme="espresso"]` nur intern — **nicht** übernehmen.)
- Der Mockup-Screen „Heute“ zeigt zwei Einstiegs-Karten (Von der Methode / Von der Bohne). Wenn die App diese Einstiege anders aufbaut: **App-Struktur behalten**, nur deren Optik angleichen. Alles, was im Mockup vorkommt, aber in der App fehlt, wird **nicht** gebaut.

## 3. Über die Designdateien

`design/Barista App.dc.html` ist eine **HTML-Designreferenz** (Hi-Fi-Prototyp), kein Produktionscode. Nicht kopieren, nicht einbinden. Sie zeigt Farben, Größen, Radien und Zustände; die Umsetzung erfolgt in den bestehenden React-/Tailwind-Komponenten. Öffnen im Browser: `support.js` und `ios-frame.jsx` müssen daneben liegen. Rechts im Mockup gibt es Sprungknöpfe zu allen Screens und einen Methodenwechsel.

**Fidelity:** High-Fidelity. Werte unten sind verbindlich.

---

## 4. Vorgehen in Phasen

Nach **jeder** Phase: `npm run pruefen` (Lint → Kontrast → Build → Tests). Commit pro Phase.

### Phase 1 — Tokens (`src/index.css`)

Ersetze **nur die Werte** im `:root`-Block (hell, „Milchkaffee“). Variablennamen bleiben. Der Dunkel-Block `html.dark` bleibt unverändert (das Mockup nutzt exakt deine bestehende „Espresso“-Palette). Fertiger Block: `tokens/index.tokens.css`.

| Token | Alt | Neu (hell) | Herkunft |
|---|---|---|---|
| `--c-paper` | `#faf4ea` | `#f5ead8` | Organic `--color-bg` |
| `--c-card` | `#fffdf9` | `#f9f4ed` | neutral-100 |
| `--c-raised` | `#f3e8d6` | `#ebddc5` | `--color-surface` |
| `--c-line` | `#e2d2ba` | `#dcd3c4` | neutral-300 |
| `--c-ink` | `#4e3629` | `#201e1d` | `--color-text` |
| `--c-mute` | `#785d47` | `#645c50` | neutral-700 |
| `--c-faint` | `#736557` | `#6b6356` | zwischen neutral-600/700, AA auf paper |
| `--c-crema` | `#8c5a2b` | `#b2622d` | accent-600 (Fläche + Icons) |
| `--c-on-crema` | `#fdf7ed` | `#fff2eb` | accent-100 |
| `--c-crema-dim` | `#d9b98c` | `#f6a06b` | accent-400 |
| `--c-ok` | `#556f40` | `#56633f` | accent-2-700 (Salbei) |
| `--c-warn` | `#905d17` | `#905d17` | unverändert |
| `--c-bad` | `#a6402f` | `#a6402f` | unverändert |

**Neu hinzufügen** (hell und dunkel), damit Akzent-**Text** AA erreicht:

| Token | Hell | Dunkel | Zweck |
|---|---|---|---|
| `--c-crema-ink` | `#8c491a` | `#e8c390` | Akzentfarbe für Text in Fließtextgröße |
| `--c-crema-tint` | `rgba(198,113,57,.10)` | `rgba(217,165,102,.14)` | hinterlegte Auswahl/Empfehlung |
| `--c-ok-tint` | `rgba(122,138,94,.16)` | `rgba(143,179,107,.16)` | „Im Fenster“, „Sehr geeignet“ |

In `@theme inline` ergänzen: `--color-crema-ink`, `--color-crema-tint`, `--color-ok-tint` (auf die `--c-*` gemappt) sowie:

```css
--font-display: 'Caprasimo', ui-rounded, system-ui, serif;
--font-sans: 'Figtree', -apple-system, BlinkMacSystemFont, system-ui, sans-serif;
--radius-card: 24px;
--radius-panel: 28px;
--radius-sheet: 32px;
--shadow-soft: 0 3px 10px rgba(46,43,37,.16);
--shadow-float: 0 12px 32px rgba(46,43,37,.22);
```

Die Schriftskala `--text-*` bleibt. `--c-roast-*` und `--c-origin-*` bleiben unverändert. Dunkel: `theme-color` in `index.html` nicht ändern; hell auf `#f5ead8` setzen.

### Phase 2 — Schriften

- Caprasimo 400 und Figtree 400/600/700/800 als **woff2 selbst hosten** unter `public/fonts/` (PWA muss offline funktionieren — kein Google-Fonts-CDN). Quelle: Google Fonts (OFL-Lizenz).
- `@font-face` mit `font-display: swap` in `index.css`; die zwei meistgenutzten Schnitte (Figtree 400, Caprasimo 400) in `index.html` per `<link rel="preload" as="font" crossorigin>`.
- Prüfen, ob `vite-plugin-pwa` `woff2` in `globPatterns` precacht; sonst ergänzen (Konfiguration, keine Funktion).
- Caprasimo hat **nur 400**. Überall, wo sie eingesetzt wird, `font-semibold/bold` entfernen (sonst Faux-Bold).

### Phase 3 — Grundbausteine (`src/components/ui.tsx`)

Nur `className`/Styles. Signaturen bleiben.

| Komponente | Neu |
|---|---|
| `Header` | Kein `border-b`. Titel `font-display font-normal`, `large` → 36px / Zeilenhöhe 1.04, sonst 26px / 1.1, `tracking-[-0.01em]`. Untertitel 15px `text-mute`. Zurück-Pfeil `text-crema-ink`, strokeWidth 2.6. |
| `GearButton`, `LogButton` | 44×44 rund, `hover/active:bg-raised`. Icon-Strich 2.4. |
| `Section` | Überschrift: 11px, `font-bold`, `tracking-[0.12em]`, uppercase, `text-faint`, `mb-2`. `px-5 pt-6`. |
| `Card` | `rounded-[24px] bg-card border border-line p-4`. `tone=accent` → `border-[1.5px] border-crema bg-crema-tint`. `warn/bad` → Randfarbe 1.5px, Fläche bleibt `bg-card`. Klickbar: `hover:border-crema active:scale-[.99]`. |
| `Button primary` | `rounded-full bg-crema text-on-crema font-bold shadow-soft hover:bg-crema-ink`. |
| `Button secondary` | `rounded-full border-2 border-crema bg-transparent text-crema-ink font-bold` (Outline statt Fläche). |
| `Button ghost` | `rounded-full text-crema-ink font-bold hover:bg-crema-tint`. |
| `Button danger` | `rounded-full border-[1.5px] border-bad/40 text-bad bg-transparent`. |
| Größen | `sm` h-11 (44) · 15px · `md` h-[52px] · 16px · `lg` h-[60px] · 18px. Horizontal `px-5`/`px-6`. |
| `Chip` | `min-h-11 px-3.5 rounded-full border-[1.5px] text-[14px]`. Aus: `border-line text-mute font-medium`. An: `border-crema bg-crema-tint text-crema-ink font-bold`. Positiv-Variante (falls vorhanden): `border-ok bg-ok-tint text-ok`. |
| `SegmentedControl` | Schiene `p-1 rounded-full bg-raised`, Optionen `h-[46px] rounded-full flex-1`. Aktiv: `bg-crema text-on-crema font-bold`; inaktiv: transparent, `text-mute font-semibold`. |
| `Field` / `TextInput` / `Select` | Label = Kicker-Stil (11px bold, 0.12em, uppercase, faint). Eingabe `h-12 rounded-[16px] bg-raised border-[1.5px] border-line`, Fokus `border-crema`. Schriftgröße mind. 16px (iOS-Zoom!). |
| `Stepper` | Minus/Plus je 62×62, `rounded-[20px] bg-raised border-[1.5px] border-line text-crema-ink text-[28px]`. Wertfeld gleiche Höhe, Zahl 26px `font-extrabold tnum`, Einheit 14px `text-mute`. |
| `Toggle` | Spur `rounded-full`, an = `bg-ok`, Knopf `bg-card shadow-soft`. |
| `InfoDot` | Kreis, Rand `border-line`, Ziffer/Icon `text-faint`; Popover wie `Sheet`-Fläche mit `rounded-[20px]`. |
| `Sheet` | `rounded-t-[32px] bg-card shadow-float px-5 pt-[22px] pb-10`. Griff 44×5 `rounded-full bg-line mx-auto mb-4`. Backdrop `rgba(28,21,18,.55)`. Einblenden `translateY(16px)→0`, 220 ms ease-out. Titel `font-display text-[26px] leading-[1.1]`. |
| `Stat` | Karte `rounded-[20px] bg-card border border-line px-3.5 py-3`. Label 10px bold 0.1em uppercase faint; Wert 21px `font-extrabold tnum`; Einheit 12px semibold mute. |
| `Triad` | Container `rounded-[28px] bg-card border border-line px-4 pt-5 pb-4`, 3 Spalten, mittlere mit `border-x border-line`, zentriert. Label 11px bold 0.1em uppercase faint; Zahl 28px `font-extrabold leading-none tnum`; Einheit 13px semibold mute; Unterzeile 11px faint. Editierbare Zahl: `border-b border-dashed border-crema pb-1`. |
| `MetaRow` | `flex-wrap gap-x-3.5 gap-y-1.5 text-[13px]`, Label `text-faint`, Wert `font-bold text-mute tnum`; Ratio-Wert `text-ok`. |
| `Empty` | Zentriert, Titel `font-display text-[22px]`, Text 15px mute. |
| `FreshnessRing` | 48×48, Strich 4, Spur `stroke-line`, Wert `stroke-ok` (frisch) / `stroke-bad` (alt), `stroke-linecap-round`, Zahl mittig 13px bold tnum. |
| `num`, `fmtClock` | **Nicht ändern.** |

### Phase 4 — System-Leisten (`src/components/system.tsx`)

`BackupBanner`, `SetupNudge`, `UndoBar`, `StorageErrorBar`, `UpdateToast`, `InstallGuide`: gleiche Logik, nur:
- Banner/Nudge = `Card`-Optik (`rounded-[24px]`), Aktion als `Button ghost`/`secondary`.
- Toasts/UndoBar: `rounded-[20px] bg-ink text-paper px-[18px] py-3.5 text-[14px] font-semibold shadow-float`, 20 px Seitenabstand, 200 ms Rise-Animation.

### Phase 5 — Screens (`src/screens/*.tsx`, restliche `components/*.tsx`)

Nur Klassen. Suche-und-ersetze-Durchgang, jede Stelle einzeln prüfen:

| Suchen | Ersetzen durch |
|---|---|
| `rounded-2xl` bei Karten/Listenflächen | `rounded-[24px]` |
| `rounded-xl` bei Buttons/Chips | `rounded-full` |
| `text-crema` auf Text ≤ 17px | `text-crema-ink` (Icons/Rahmen dürfen `crema` bleiben) |
| `bg-crema/15`, `bg-crema/10` | `bg-crema-tint` |
| `bg-ok/15` o. ä. | `bg-ok-tint` |
| `font-semibold` auf `h1`/`h2`-Titeln | `font-display font-normal` |
| Icon-`strokeWidth` 1.5–2.2 | 2.4 (Navigation/Pfeile 2.6) |

Screen-spezifisch (siehe Mockup-Sprünge):
- **HeuteScreen** — Titel groß in Caprasimo. Einstiege/Hauptaktionen als große Karte: `p-5 rounded-[28px]`, Icon in 46 px Ring (2px Rand; Methode = `crema`, Bohne = `ok`), Titel 18px bold, Unterzeile 13px mute, Chevron rechts. Die primäre Karte trägt `border-[1.5px] border-crema bg-crema-tint`. Schwebender Brüh-Knopf bleibt, wie er ist (Position über `--nav-h`), nur Optik → `Button primary lg`.
- **MethodPicker / BeanPicker** — Listenzeile = `Card` klickbar. Eignungsplakette: `px-2.5 py-0.5 rounded-full text-[11px] font-bold`. „Sehr geeignet“: `bg-ok-tint text-ok`, Zeilenrand `border-ok`. „Geeignet“: `bg-crema-tint text-crema-ink`. „Mit Abstrichen“: transparent, `text-warn`. Begründungssatz 13px `text-faint leading-[1.4]`. Röstband rechts als 6 px breiter, 44 px hoher Pillenstreifen in `--c-roast-n`.
- **BrewScreen / SessionLauf / brewphases** — Timerring 286 px, Strich 14: Spur `stroke-raised`, Zielfenster `stroke-ok` mit Deckkraft .38, Fortschritt in Status­farbe (`ok` im Fenster, `warn` zu früh, `bad` zu lang, `crema` bereit), `round`-Kappen. Zahl `font-extrabold tracking-[-0.04em] leading-[.9] tnum`: 96px bei Sekunden, 80px bei m:ss. Statuspille darunter `px-3.5 py-1.5 rounded-full text-[14px] font-bold` (immer mit Wort, nie nur Farbe). Start = `Button primary` h-[72px] text-[20px]; Stopp = Outline h-[72px] `border-2 border-crema text-crema-ink`. Phasenhinweis 14px mute zentriert, `max-w-[32ch]`. Erfassen-Phase = `Sheet`. Auswertung: Urteil `font-display text-[34px]`, „Nächster Schritt“-Karte `rounded-[28px] border-[1.5px] border-crema bg-crema-tint p-[18px]`, Ratschlag 21px extrabold. Sterne je `h-[52px] flex-1 rounded-[16px] border-[1.5px]`.
- **BeansScreen / BeanDetail / BeanForms** — Karten `rounded-[24px]`, FreshnessRing links, Tag-Pille unter Meta. „Tüte hinzufügen“ als Outline-Button h-14.
- **LogScreen** — Zeilen ohne Karte, `min-h-[60px] border-b border-line`. Linke Zahlkachel 46×44 `rounded-[14px] bg-raised`, Zahl 15px extrabold, Einheit 9px bold uppercase faint. Sterne `text-crema tracking-[.12em]`.
- **SetupScreen** — Einstellungsgruppen als `Card` mit Kicker-Label; Tiefe/Darstellung als `SegmentedControl`.
- **OriginMap, GrinderDial, SageGrindDial, beanviz, geschmackspad, lernkurve, vorhersage, getraenke** — nur Farbzuweisungen auf die neuen Tokens prüfen (sie lesen bereits `--c-*`). Geometrie, Skalen, Interaktion **nicht** anfassen. Nur Strichstärken/Radien angleichen, wo es offensichtlich ist.
- **Reiterleiste** (falls vorhanden) — Beschriftung 11px uppercase `tracking-[.06em]`; aktiv `text-crema-ink font-bold`, inaktiv `text-faint font-medium`. Höhe über `--nav-h` bleibt.

### Phase 6 — Abnahme

1. `npm run pruefen` grün.
2. `git diff --stat` darf nur `index.css`, `index.html`, `public/fonts/*`, ggf. `vite.config.ts` (nur precache-Pattern) sowie `components/*.tsx`/`screens/*.tsx` zeigen.
3. `git diff src/screens src/components | grep '^[+-]' | grep -v className | grep -v style` sollte nahezu leer sein (nur SVG-`strokeWidth`).
4. Sichtprüfung hell und dunkel auf 375 px: Heute → Methode → Bohne → Startpunkt → Lauf → Erfassen → Auswertung → Logbuch → Setup.
5. Lighthouse-Vergleich gegen `docs/lighthouse-after-p6.json`: Accessibility darf nicht sinken.

---

## 5. Design-Tokens (Referenz)

**Farbe hell:** siehe Tabelle Phase 1. **Dunkel:** unverändert aus `html.dark` + die drei neuen Tokens.

**Typografie**
- Display: Caprasimo 400 — 36 (Start), 34 (Screentitel), 32 (Auswahl), 26 (Sheet/Setup), 24/22 (Karten­überschrift)
- Body: Figtree — 18/700 Karten­titel, 16–17/700 Listen­titel, 15/400 Fließtext, 13/400 Meta, 11/700 Kicker (0.12–0.18em, uppercase)
- Zahlen: Figtree 800, `tabular-nums`. Timer 96/80, Triade 28 (Start) / 24 (Auswertung), Stat 21
- Zeilenhöhen: Display 1.04–1.1, Text 1.4–1.55

**Radien:** 14 (Log-Kachel) · 16 (Eingaben, Sterne) · 20 (Stat, Stepper, Toast) · 24 (Karte) · 28 (Panel/Triade) · 32 (Sheet oben) · 999 (Buttons, Chips, Pillen, Segment)

**Abstände:** Seitenrand 20 px · Kartenabstand 10–12 px · Sektion oben 22–26 px · Karten­innenabstand 16–20 px

**Touchziele:** mind. 44 px; Laufkontrolle-Hauptknopf 72 px, Sticky-Primärknopf 60 px.

**Schatten:** `soft` 0 3 10 rgba(46,43,37,.16) — nur Primärknopf & schwebende Elemente · `float` 0 12 32 rgba(46,43,37,.22) — Sheet, Toast. Karten haben **keinen** Schatten, nur Rand.

**Bewegung:** Rise 16 px → 0, 200–220 ms ease-out. Drücken `scale(.985–.99)`. `prefers-reduced-motion` bleibt wie im Repo.

## 6. Assets

- Schriften: Caprasimo, Figtree (Google Fonts, OFL) — selbst hosten.
- Icons: bestehende Inline-SVGs behalten, nur Strichstärke (Lucide-Charakter, rund). Keine neue Icon-Bibliothek.
- Keine Bilder neu.

## 7. Dateien in diesem Paket

- `README.md` — diese Anleitung
- `tokens/index.tokens.css` — fertiger `:root`-Block + Ergänzungen für `html.dark` und `@theme`
- `design/Barista App.dc.html` — Hi-Fi-Referenz aller Screens (im Browser öffnen)
- `design/ios-frame.jsx`, `design/support.js` — nur zum Anzeigen der Referenz nötig
